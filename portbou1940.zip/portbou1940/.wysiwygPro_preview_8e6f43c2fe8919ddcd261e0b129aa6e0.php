<?php
if ($_GET['randomId'] != "I78aDWY0IMZG2e7nHaooRP_PIimTmOqfdPvgxP8Rq0BsgcHtLhNGn58posfGOi2B") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
