<?php
if ($_GET['randomId'] != "JPH9ktBdLXGDp11sgE6PhVFdRZmIddaAN3YsWYZLZ6wu5C5_YloDRkhMQe2mRIv_") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
